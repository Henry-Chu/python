'''
加入了電子商務公司成為其程式開發部門的實習生。
你的程式中有一個地方要讓使用者提供一個數值。
即使使用者輸入了小數，該值也必須轉換為整數來進行計算。
你應該使用哪個程式碼片

A. totalNums = input("總共有幾筆資料?")
B. totalNums = int(input("總共有幾筆資料?"))
c. totalNums = str(input("總共有幾筆資料?"))
D. totalNums = float(input("總共有幾筆資料?"))
'''
