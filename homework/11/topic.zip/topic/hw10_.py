'''
你開發了一個比較數字的Python程式，下列何的值是True?(可複選)
( )A. 0 or 5
( )B. bool(0)
( )C. None is None
( )D. -5<0<5
'''
