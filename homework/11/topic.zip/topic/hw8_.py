'''
你設計了一個Python程式用來顯示每個員工每天工作到現在的小時數。
你需要計算工作時數並顯示訊息。程式碼如下:
01 start = input("你今天幾點開始工作?")
02 end = input("現在幾點?")
03
如果要完成這個程式,在03行應使用哪個程式碼?
A. print("你已經工作了" + str(int(end) - int(start)) + "小時!")
B. print("你已經工作了" + (int(end) - int(start)) + "小時!")
C. print("你已經工作了" + str(end - start) + "小時!")
D. print("你已經工作了" + int(end - start) + "小時!")
'''
