'在Python程式中我們利用type()查詢每個值的資料類別，以下的程式執行後出現的資料類別分別是:'
type(+1E10)
type(5.0)
type("True")
type(False)
'''
A. int, int, bool, bool
B. float, float, str, bool
c. int, float, str, bool
D. float, int, str, str
'''
