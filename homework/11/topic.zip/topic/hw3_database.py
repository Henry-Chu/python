'''
你正在編寫一個Python程式記錄客戶資料並將其儲存在資料庫中。
這個程式處理各種各樣的資料。
以下的變數宣告後他們的資料類別是?請將嘗試碼進行正確的分類。
int:apple、
bool:
str:
float:
example 
apple = 1000
'''
age = 12
minor = False
name = "David"
weight = 64.5
zip = "545"
